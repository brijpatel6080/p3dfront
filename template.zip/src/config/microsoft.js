// export default {
//   auth: {
//     clientId: YOUR_CLIENT_ID,
//     authority: YOUR_AUTHORITY,
//   },
//   redirectUri: YOUR_REDIRECT_URI,
// };
